<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$data = array(
				'nama' => "Bagus Dwi Prayitno",
				'nim'  => "1541180198",
				'alamat' => "Pandaan City",
				'no_hp' => '085648109194',
				'hobby' => 'Silat',
			);
		$this->load->view('about',$data);		
	}

}

/* End of file About.php */
/* Location: ./application/controllers/About.php */

 ?>